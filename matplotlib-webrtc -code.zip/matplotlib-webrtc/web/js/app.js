let peerConnection = null;
let dataChannel = null;

let resolutionMap = {
  screenWidth: 0,
  screenHeight: 0,
  canvasWidth: 0,
  canvasHeight: 0,
};

let currentRemoteMousePos = {
  x: 0,
  y: 0
}

let canvasElement = 'screen-canvas'
let videoElement = 'screen-video'


function showError (error) {
  const errorNode = document.querySelector("#error");
  if (errorNode.firstChild) {
    errorNode.removeChild(errorNode.firstChild);
  }
  errorNode.appendChild(document.createTextNode(error.message || error));
}

function startSession (offer, screen) {
  return fetch("/api/session", {
    method: "POST",
    body: JSON.stringify({
      offer,
      screen,
    }),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((res) => {
      return res.json();
    })
    .then((msg) => {
      return msg.answer;
    });
}

function createOffer (pc, { audio, video }) {
  return new Promise((accept, reject) => {
    pc.onicecandidate = (evt) => {
      if (!evt.candidate) {
        const { sdp: offer } = pc.localDescription;
        accept(offer);
      }
    };
    pc.createOffer({
      offerToReceiveAudio: audio,
      offerToReceiveVideo: video,
    })
      .then((ld) => {
        pc.setLocalDescription(ld);
      })
      .catch(reject);
  });
}

function sendDataMessage (command, data) {
  if (dataChannel) {
    // Send cordinates
    console.log(JSON.stringify({
      command: command,
      data: data,
    }));
    dataChannel.send(
      JSON.stringify({
        command: command,
        data: data,
      })
    );
  }
}

function enableMouseEvents (dataChannel) {
  // Start sending mouse cordinates on mouse move in canvas
  const canvas = document.getElementById(canvasElement);

  // On Mouse move
  canvas.addEventListener("mousemove", (event) => {

    // Get cordinates
    const cordinates = scaleCordinatesForDesktop(event.clientX, event.clientY);

    // Send cordinates
    sendDataMessage("mousemove", {
      x: cordinates.x,
      y: cordinates.y,
    });
  });

  // On Mouse Click
  canvas.addEventListener("mousedown", (event) => {
    let button = "left";

    switch (event.which) {
      case 1:
        button = "left";
        break;

      case 2:
        button = "center";
        break;

      case 3:
        button = "right";
        break;

      default:
        button = "left";
    }

    sendDataMessage("click", {
      button,
    });
  });

  // On Mouse Double Click
  canvas.addEventListener("dblclick", (event) => {
    let button = "left";

    switch (event.which) {
      case 1:
        button = "left";
        break;

      case 2:
        button = "center";
        break;

      case 3:
        button = "right";
        break;

      default:
        button = "left";
    }

    sendDataMessage("dblclick", {
      button,
    });
  });

  // Read keyboard events
  document.addEventListener("keydown", (event) => {
    sendDataMessage("keydown", {
      keyCode: event.keyCode,
    });
  });
}

function scaleRemoteCordinatesToLocalDisplay () {

  const xPer = (currentRemoteMousePos.x / resolutionMap.screenWidth) * 100
  const yPer = (currentRemoteMousePos.y / resolutionMap.screenHeight) * 100

  const localX = ((resolutionMap.canvasWidth * xPer) / 100).toFixed(0)
  const localY = ((resolutionMap.canvasHeight * yPer) / 100).toFixed(0)

  return {
    x: localX,
    y: localY
  }
}

function scaleCordinatesForDesktop (posX, posY) {
  const remoteCanvas = document.getElementById(canvasElement);
  // Get canvas size
  const rect = remoteCanvas.getBoundingClientRect();
  // Get mouse cordinates on canvas
  const x = (posX - rect.left).toFixed(0);
  const y = (posY - rect.top).toFixed(0);

  const xPer = (x / resolutionMap.canvasWidth) * 100;
  const yPer = (y / resolutionMap.canvasHeight) * 100;
  
  return {
    x: ((resolutionMap.screenWidth * xPer) / 100).toFixed(0),
    y: ((resolutionMap.screenHeight * yPer) / 100).toFixed(0),
  };
}

function startRemoteSession (screen, remoteVideoNode, stream) {
  let pc;

  return Promise.resolve()
    .then(() => {
      pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
      });

      dataChannel = pc.createDataChannel("messages");

      dataChannel.onopen = function (event) {
        enableMouseEvents(dataChannel);

        // Fetch screen size from server
        sendDataMessage("screensize", {});
      };

      dataChannel.onmessage = function (event) {
        try {
          const message = JSON.parse(event.data);
          switch (message.command) {
            case "screensize":
              resolutionMap.screenHeight = message.data.height;
              resolutionMap.screenWidth = message.data.width;
              currentRemoteMousePos.x = message.data.mouseX
              currentRemoteMousePos.y = message.data.mouseY
              break;

            case "mousetouchmove":
              currentRemoteMousePos.x = message.data.x
              currentRemoteMousePos.y = message.data.y
              break;
          }
        } catch (e) {
          console.error(e);
        }
      };

      pc.ontrack = (evt) => {
        remoteVideoNode.srcObject = evt.streams[0];
        remoteVideoNode.play();
      };

      stream &&
        stream.getTracks().forEach((track) => {
          pc.addTrack(track, stream);
        });

      return createOffer(pc, { audio: false, video: true });
    })
    .then((offer) => {
      return startSession(offer, screen);
    })
    .then((answer) => {
      return pc.setRemoteDescription(
        new RTCSessionDescription({
          sdp: answer,
          type: "answer",
        })
      );
    })
    .then(() => pc);
}

function resizeCanvas (canvas, video) {
  const w = video.offsetWidth;
  const h = video.offsetHeight;
  canvas.width = w;
  canvas.height = h;

  resolutionMap.canvasHeight = h;
  resolutionMap.canvasWidth = w;
}

function disconnectSession () {
  sendDataMessage("terminate", {});
  peerConnection.close();
  peerConnection = null;
  dataChannel = null;
  enableStartStop(true);
  setStartStopTitle("Connect");
}

const enableStartStop = (enabled) => {
  const startStop = document.querySelector("#start-stop");
  if (enabled) {
    startStop.removeAttribute("disabled");
  } else {
    startStop.setAttribute("disabled", "");
  }
};

const setStartStopTitle = (title) => {
  const startStop = document.querySelector("#start-stop");
  startStop.removeChild(startStop.firstChild);
  startStop.appendChild(document.createTextNode(title));
};

function getBrowser () {
  if (typeof InstallTrigger !== 'undefined') return 'firefox'

  if (!!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime)) return 'chrome'
}

document.addEventListener("DOMContentLoaded", () => {
  let selectedScreen = 0;
  const remoteVideo = document.getElementById(videoElement);
  const remoteCanvas = document.getElementById(canvasElement);

  // Disable right click context on canvas
  remoteCanvas.oncontextmenu = function (e) {
    e.preventDefault();
  };

  const startStop = document.querySelector("#start-stop");

  remoteVideo.onplaying = () => {
    setInterval(() => {
      resizeCanvas(remoteCanvas, remoteVideo);
    }, 1000);
  };

  startStop.addEventListener("click", () => {
    enableStartStop(false);

    const browser = getBrowser()

    const userMediaPromise = navigator.mediaDevices.getUserMedia({ video: true })

    if (!peerConnection) {
      userMediaPromise.then((stream) => {
        return startRemoteSession(selectedScreen, remoteVideo, stream)
          .then((pc) => {
            remoteVideo.style.setProperty("visibility", "visible");
            peerConnection = pc;
          })
          .catch(showError)
          .then(() => {
            enableStartStop(true);
            setStartStopTitle("Disconnect");
            document.getElementById('instruction').style.display = 'none'
          });
      });
    } else {
      disconnectSession();
      document.getElementById('instruction').style.display = 'block'
      remoteVideo.style.setProperty("visibility", "collapse");
    }
  });
});

window.addEventListener("beforeunload", () => {
  if (peerConnection) {
    peerConnection.close();
  }
});
